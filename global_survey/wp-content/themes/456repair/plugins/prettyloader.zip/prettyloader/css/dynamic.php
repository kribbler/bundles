<?php
header("Content-type: text/css; charset: UTF-8");
require_once('../../../../wp-load.php');

// load PrettyLoader options
$prettyloader_options = get_option('prettyloader_options');

// load PrettyLoader API
global $prettyloader;


// Tip: I'm concerned about using @imports within this Dynamic CSS file
// I think it's more efficient & quick to use the PHP include_once method.

// ========================
// Load the main stylesheet
include_once('main.css');


// ####################################################


// =============================================
// Get styles based on the PrettyLoader settings



// ----------------------------------------------------
// STEP #1 - Container styles (background, border, etc)
if ($prettyloader_options['background-style'] == 1) { // BACKGROUND - COLOR

	// if background color is defined
	if ($prettyloader_options['background-color']) {
?>
		#prettyloader-container {
			background-color: <?php echo $prettyloader_options['background-color']; ?>
		}
<?php
	}

}

if ($prettyloader_options['background-style'] == 2) { // BACKGROUND - TRICOLOR

	// if tricolor background colors are defined
	if ($prettyloader_options['tricolor-background-top'] && $prettyloader_options['tricolor-background-left'] && $prettyloader_options['tricolor-background-right']) {
	?>
		#prettyloader-container {
			background:
				linear-gradient(
					<?php echo $prettyloader_options['tricolor-background-top']; ?>,
					transparent
				),
				linear-gradient(
					90deg,
					<?php echo $prettyloader_options['tricolor-background-left']; ?>,
					transparent
				),
				linear-gradient(
					-90deg,
					<?php echo $prettyloader_options['tricolor-background-right']; ?>,
					transparent
				);
		}
	<?php
	}

}

if ($prettyloader_options['background-style'] == 3) { // BACKGROUND - IMAGE

	// if background image has been defined
	if ($prettyloader_options['background-image']['url']) {
	?>
		#prettyloader-container {
			background-image: url(<?php echo $prettyloader_options['background-image']['url']; ?>);

	<?php
			// if background image repeat is enabled
			if ($prettyloader_options['background-image-repeat']) {
				echo 'background-repeat: repeat;';
			} else {
				// if background image isn't a tile (cover whole area)
				echo 'background-repeat: no-repeat';
				echo 'background-position: center center;';
				echo 'background-attachment: fixed;';
				// cross-browser cover
				echo '-webkit-background-size: cover;';
				echo '-moz-background-size: cover;';
				echo '-i-background-size: cover;';
				echo 'background-size: cover;';
			}

		// close #prettyloader-container
		echo '}';

	}

}


if ($prettyloader_options['background-border-switch'] == true) { // Container Border is enabled

	// get border settings
	$background_border_width        = $prettyloader_options['background-border-width'].'px';                    // Width
	$background_border_opacity      = $prettyloader_options['background-border-opacity'] / 100;               // Opacity
	$background_border_color        = $prettyloader->hex2rgb($prettyloader_options['background-border-color']); // RGBa Color
	$background_border_rgba_red     = $background_border_color['red'];
	$background_border_rgba_green   = $background_border_color['green'];
	$background_border_rgba_blue    = $background_border_color['blue'];


	// generate CSS
	$background_border_output = "
	#prettyloader-container {
		border: $background_border_width solid rgba($background_border_rgba_red, $background_border_rgba_green, $background_border_rgba_blue, $background_border_opacity);
	}
	";

	// output container border styles
	echo $background_border_output;

} else { // Container Border is disabled
	// do nothing
}

// ----------------------------------------------------



// --------------------------
// STEP #2 - Container effect
if ($prettyloader_options['page-transition'] != null) {

	// include container effect CSS
	include_once('transitions/transition-'.$prettyloader_options['page-transition'].'.css');

} else { // if no page transition is specified

	// include default (1st) container effect CSS
	include_once('transitions/transition-1.css');
}
// --------------------------




// ----------------------------
// STEP #3 - Get spinner styles
if ($prettyloader_options['type-switch'] == 1) { // IMAGE-BASED PRELOADER

	// import CSS based on chosen graphics option
	include_once('image-spinners/image-spinner-'.$prettyloader_options['spinner-image-graphics'].'.css');

} else { // PURE CSS PRELOADER

	// get spinner color (available only for the pure-css spinners)
	$spinner_color = $prettyloader_options['spinner-purecss-color'];

	// fallback (just in case)
	if ($spinner_color == null) { // if not defined set the spinner color to white
		$spinner_color = '#ffffff';
	}

	// get the rgb spinner color
	$spinner_color_rgb          = $prettyloader->hex2rgb($spinner_color);
	$spinner_color_rgb_red      = $spinner_color_rgb['red'];
	$spinner_color_rgb_green    = $spinner_color_rgb['green'];
	$spinner_color_rgb_blue     = $spinner_color_rgb['blue'];

	// get the background color (for spinner #5 & #6 - they don't fully support tricolor or background images)
	$spinner_bg_color = $prettyloader_options['background-color'];

	// we'll load appropriate CSS code in this variable
	$purecss_spinner = '';

	// if user has chosen spinner graphics
	if ($prettyloader_options['spinner-purecss-graphics'] != null) {
		include_once('../lib/purecss-spinners/purecss-spinner-'.$prettyloader_options['spinner-purecss-graphics'].'.php');
	} else {
		// include first spinner type if none selected (fallback)
		include_once('../lib/purecss-spinners/purecss-spinner-1.php');
	}


	// output purecss spinner code
	echo $purecss_spinner;

}
// ----------------------------



// DISABLE ON MOBILE DEVICES?
if ($prettyloader_options['hide-mobile'] == true) {
?>
	@media (max-width: 767px) {

		#prettyloader-container, #prettyloader-spinner {
			display: none !important;
			opacity: 0 !important;
		}
	}
<?php
}



// ####################################################
// ################### CUSTOM CSS #####################
if ($prettyloader_options['custom-css']) {
	echo $prettyloader_options['custom-css'];
}
// ####################################################