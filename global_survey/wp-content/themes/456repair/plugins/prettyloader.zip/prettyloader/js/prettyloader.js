/**
 * Created by Vasily Fotin on 18/06/14.
 * http://www.webembassy.de
 */

// #########################################
// ######### PrettyLoader JS Object ########
// #########################################
var prettyLoader = {

	// --------------------
	// Inject HTML function
	'initLoader': function( containerClass, spinnerClass, showCredit ) {

		var bodyTag            = jQuery('body'), // PrettyLoader will be inserted right at the beginning of <body> tag
			containerClassHTML = '', // HTML string with container class
			spinnerClassHTML   = '', // HTML string with spinner class
			creditText         = ''; // Credit text placeholder

		// check container class
		if (containerClass != undefined) {
			containerClassHTML = 'class="'+containerClass+'"'; // open the container by default (on page load)
		}

		// check spinner class
		if (spinnerClass != undefined) {
			spinnerClassHTML = 'class="'+spinnerClass+'"';
		}

		// show credit?
		if (showCredit == 1) {
			creditText = '<a href="http://www.webembassy.de/en/prettyloader/" target="_blank" id="prettyloader-credit">Powered by PrettyLoader</a>';
		} else {
			// don't show the credit
		}

		// insert the PrettyLoader container & spinner HTML
		bodyTag.prepend('<div id="prettyloader-container" '+containerClassHTML+'>' +
							'<div id="prettyloader-spinner" '+spinnerClassHTML+'></div>' +
							creditText +
						'</div>');
	},


	'toggleLoader': function() {

		var overlay = document.querySelector( '#prettyloader-container' );
		transEndEventNames = {
			'WebkitTransition': 'webkitTransitionEnd',
			'MozTransition': 'transitionend',
			'OTransition': 'oTransitionEnd',
			'msTransition': 'MSTransitionEnd',
			'transition': 'transitionend'
		},
			transEndEventName = transEndEventNames[ Modernizr.prefixed( 'transition' ) ],
			support = { transitions : Modernizr.csstransitions };


		if( classie.has( overlay, 'open' ) ) {
			classie.remove( overlay, 'open' );
			classie.add( overlay, 'close' );
			var onEndTransitionFn = function( ev ) {
				if( support.transitions ) {
					if( ev.propertyName !== 'visibility' ) return;
					this.removeEventListener( transEndEventName, onEndTransitionFn );
				}
				classie.remove( overlay, 'close' );
			};
			if( support.transitions ) {
				overlay.addEventListener( transEndEventName, onEndTransitionFn );
			}
			else {
				onEndTransitionFn();
			}
		}
		else if( !classie.has( overlay, 'close' ) ) {
			classie.add( overlay, 'open' );
		}


	},



	// ---------------------
	// Initialize the Effect
	'initEffect': function( delay ) {

		// delay fallback
		if (delay == undefined) {
			delay = 500;
		}

		// slowly show the spinner
		jQuery('#prettyloader-spinner').fadeIn('slow');


		setTimeout(function() {
			// Toggle PrettyLoader (close)
			prettyLoader.toggleLoader();
		}, delay);

	}
};