<?php
/*
   Plugin Name: PrettyLoader
   Plugin URI: http://prettyloader.webembassy.de
   Description: Sweet & pretty page transitions and loaders of your choice, regardless of what WordPress theme you're using.
   Version: 1.0
   Author: Vasi Fotin
   Author URI: http://www.webembassy.de
   License: You should have purchased a license from CodeCanyon.net
   Copyright 2014 Vasi Fotin http://www.webembassy.de
*/

// Block direct script access attempts
if ( !function_exists( 'add_action' ) ) {
	echo 'No direct access.';
	exit;
}

// define plugin location
define( 'PRETTYLOADER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PRETTYLOADER_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );


// Redux Options Framework
if ( !class_exists( 'ReduxFramework' ) && file_exists( PRETTYLOADER_PLUGIN_DIR . 'admin/ReduxCore/framework.php' ) ) {
	require_once( PRETTYLOADER_PLUGIN_DIR . 'admin/ReduxCore/framework.php' );
}
// PrettyLoader Options Panel
if ( !isset( $prettyloader_options ) && file_exists( PRETTYLOADER_PLUGIN_DIR . 'admin/prettyloader/prettyloader-config.php' ) ) {
	require_once( PRETTYLOADER_PLUGIN_DIR . 'admin/prettyloader/prettyloader-config.php' );
}
// PrettyLoader Options Panel CSS
function addPanelCSS() {
	$adminpanelcss_url = PRETTYLOADER_PLUGIN_URL.'admin/prettyloader/style.css';

	wp_register_style(
		'redux-custom-css',
		$adminpanelcss_url,
		array( 'redux-css' ), // Be sure to include redux-css so it's appended after the core css is applied
		time(),
		'all'
	);
	wp_enqueue_style('redux-custom-css');
}
add_action( 'redux/page/prettyloader_options/enqueue', 'addPanelCSS' );


// ##################################
// ######### Load Settings ##########
// ##################################
$prettyloader_options = get_option('prettyloader_options');


// check if PrettyLoader is turned on
if ($prettyloader_options['prettyloader-switch'] == true) {

	// alrighty, do action!

	// PrettyLoader API
	require_once( PRETTYLOADER_PLUGIN_DIR.'lib/api.php' );

	// init PrettyLoader
	$prettyloader = new prettyloader();


	// load dynamic CSS
	$prettyloader->enqueueStyle('prettyloader_dynamic', PRETTYLOADER_PLUGIN_URL.'css/dynamic.php');


	// load PrettyLoader dependencies
	$prettyloader->enqueueScript('modernizr', PRETTYLOADER_PLUGIN_URL.'js/modernizr.custom.js');
	$prettyloader->enqueueScript('classie_script', PRETTYLOADER_PLUGIN_URL.'js/classie.js');
	
	// load PrettyLoader JS
	wp_register_script('prettyloader_script', PRETTYLOADER_PLUGIN_URL.'js/prettyloader.min.js', array('jquery', 'modernizr', 'classie_script'), null, false);
	wp_enqueue_script('prettyloader_script');
	

}