<?php
/**
 * Created by Web Embassy.
 * Developer: Vasily Fotin
 * Date: 19/06/14
 * Time: 20:07
 */

$purecss_spinner = "
		#prettyloader-spinner {
			text-indent: -9999em;
			width: 11em;
			height: 11em;
			border-radius: 50%;
			background: $spinner_color;
			background: -moz-linear-gradient(left, $spinner_color 10%, rgba($spinner_color_rgb_red, $spinner_color_rgb_green, $spinner_color_rgb_blue, 0) 42%);
			background: -webkit-linear-gradient(left, $spinner_color 10%, rgba($spinner_color_rgb_red, $spinner_color_rgb_green, $spinner_color_rgb_blue, 0) 42%);
			background: -o-linear-gradient(left, $spinner_color 10%, rgba($spinner_color_rgb_red, $spinner_color_rgb_green, $spinner_color_rgb_blue, 0) 42%);
			background: -ms-linear-gradient(left, $spinner_color 10%, rgba($spinner_color_rgb_red, $spinner_color_rgb_green, $spinner_color_rgb_blue, 0) 42%);
			background: linear-gradient(to right, $spinner_color 10%, rgba($spinner_color_rgb_red, $spinner_color_rgb_green, $spinner_color_rgb_blue, 0) 42%);
			-webkit-animation: prettyloader-spinner-animation 1.4s infinite linear;
			animation: prettyloader-spinner-animation 1.4s infinite linear;
		}
		#prettyloader-spinner:before {
			width: 50%;
			height: 50%;
			background: $spinner_color;
			border-radius: 100% 0 0 0;
			position: absolute;
			top: 0;
			left: 0;
			content: '';
		}
		#prettyloader-spinner:after {
			background: $spinner_bg_color;
			width: 75%;
			height: 75%;
			border-radius: 50%;
			content: '';
			margin: auto;
			position: absolute;
			top: 0;
			left: 0;
			bottom: 0;
			right: 0;
		}
		
		@-webkit-keyframes prettyloader-spinner-animation {
			0% {
				-webkit-transform: rotate(0deg);
				transform: rotate(0deg);
			}
			100% {
				-webkit-transform: rotate(360deg);
				transform: rotate(360deg);
			}
		}
		@keyframes prettyloader-spinner-animation {
			0% {
				-webkit-transform: rotate(0deg);
				transform: rotate(0deg);
			}
			100% {
				-webkit-transform: rotate(360deg);
				transform: rotate(360deg);
			}
		}
		
";