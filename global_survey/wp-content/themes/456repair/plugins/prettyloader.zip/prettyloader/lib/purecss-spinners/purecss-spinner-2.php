<?php
/**
 * Created by Web Embassy.
 * Developer: Vasily Fotin
 * Date: 19/06/14
 * Time: 20:07
 */

$purecss_spinner = "
	#prettyloader-spinner {
		text-indent: -9999em;
		border-top: 1.1em solid rgba($spinner_color_rgb_red, $spinner_color_rgb_green, $spinner_color_rgb_blue, 0.2);
		border-right: 1.1em solid rgba($spinner_color_rgb_red, $spinner_color_rgb_green, $spinner_color_rgb_blue, 0.2);
		border-bottom: 1.1em solid rgba($spinner_color_rgb_red, $spinner_color_rgb_green, $spinner_color_rgb_blue, 0.2);
		border-left: 1.1em solid $spinner_color;
		-webkit-animation: prettyloader-spinner-animation 1.1s infinite linear;
		animation: prettyloader-spinner-animation 1.1s infinite linear;
	}
	#prettyloader-spinner,
	#prettyloader-spinner:after {
		border-radius: 50%;
		width: 10em;
		height: 10em;
	}


	@-webkit-keyframes prettyloader-spinner-animation {
		0% {
			-webkit-transform: rotate(0deg);
			transform: rotate(0deg);
		}
		100% {
			-webkit-transform: rotate(360deg);
			transform: rotate(360deg);
		}
		}
	@keyframes prettyloader-spinner-animation {
		0% {
			-webkit-transform: rotate(0deg);
			transform: rotate(0deg);
		}
		100% {
			-webkit-transform: rotate(360deg);
			transform: rotate(360deg);
		}
	}
";