<?php
/**
 * Created by Web Embassy.
 * Developer: Vasily Fotin
 * Date: 17/06/14
 * Time: 19:51
 */

class prettyloader {

	public $options;

	public function __construct() {

		// Load PrettyLoader Options
		$this->options = get_option('prettyloader_options');

		// Force jQuery option
		if ($this->options['force-jquery'] == true)  {
			$this->jQueryLoad();
		}

		// do action
		$this->outputPrettyLoader();
	}
	


	// ###################################################
	// ########### Enqueue CSS style function ############
	// ###################################################
	public function enqueueStyle( $name, $url ) {

		if ($name && $url) {
			// enqueue CSS
			wp_enqueue_style($name, $url, false, null);

			// everything went well
			return true;
		}

		return false;
	}


	// ###################################################
	// ########### Enqueue JS script function ############
	// ###################################################
	public function enqueueScript( $name, $url ) {

		if ($name && $url) {

			// jQuery dependency & place in the <head> section
			wp_register_script($name, $url, array('jquery'), null, false);

			// enqueue script
			wp_enqueue_script($name);

			// everything went well
			return true;
		}

		return false;
	}


	// ###################################################
	// ############## Force jQuery CDN load ##############
	// ###################################################
	public function jQueryLoad() {

		// deregister old jQuery
		wp_dequeue_script('jquery');
		wp_deregister_script('jquery');

		// load jQuery from Google CDN
		wp_register_script('jquery', '//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js', false, null, false);
		wp_enqueue_script('jquery');
	}


	// ###################################################
	// ############ HEX2RGB Color Converter ##############
	// ###################################################
	public function hex2rgb( $colour ) {

		if ( $colour[0] == '#' ) {
			$colour = substr( $colour, 1 );
		}
		if ( strlen( $colour ) == 6 ) {
			list( $r, $g, $b ) = array( $colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5] );
		} elseif ( strlen( $colour ) == 3 ) {
			list( $r, $g, $b ) = array( $colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2] );
		} else {
			return false;
		}
		$r = hexdec( $r );
		$g = hexdec( $g );
		$b = hexdec( $b );
		return array( 'red' => $r, 'green' => $g, 'blue' => $b );
	}


	// #################################################
	// ########## Initialize PrettyLoader JS ###########
	// #################################################
	public function initJS() {

		// ------------
		// Spinner Size
		$spinner_class_size = 'prettyloader-spinner-medium'; // default fallback

		switch ($this->options['spinner-size']) {
			case '1':   // small
				$spinner_class_size = 'prettyloader-spinner-small';
				break;
			case '2':   // medium
				$spinner_class_size = 'prettyloader-spinner-medium';
				break;
			case '3':   // large
				$spinner_class_size = 'prettyloader-spinner-large';
				break;
		}


		// ------------
		// Spinner Type
		$spinner_class_type = 'prettyloader-spinner-image'; // default fallback

		switch ($this->options['type-switch']) {
			case true:  // image spinner
				$spinner_class_type = 'prettyloader-spinner-image';
				break;
			case false:  // pure CSS spinner
				$spinner_class_type = 'prettyloader-spinner-css';
				break;
		}


		// ----------------
		// Spinner Graphics
		$spinner_class_graphics = 'prettyloader-spinner-image-1'; // default fallback

		if ($this->options['type-switch'] == 1) { // IMAGE SPINNER
			$spinner_class_graphics = 'prettyloader-spinner-image-'.$this->options['spinner-image-graphics'];
		}

		if ($this->options['type-switch'] == 0) { // PURE CSS SPINNER
			$spinner_class_graphics = 'prettyloader-spinner-purecss-'.$this->options['spinner-purecss-graphics'];
		}


		// ====================================
		// combine all spinner classes together
		$spinner_class = $spinner_class_size.' '.$spinner_class_type.' '.$spinner_class_graphics;



		// -----------------------------------
		// Enable / Disable Smooth Transitions

		if ($this->options['smooth-page-transitions'] == true) { // smooth transitions are enabled

			$permalink = get_permalink();

			// listen for <a> element clicks
			$a_listener = "
				jQuery('a').click(function(){

					// 1. Check <a> is not part of Bootstrap toggles
					// 2. Check if <a> links to the same page (starts with a hashtag)
					if ( (jQuery(this).attr('data-toggle') == undefined) && (jQuery(this).attr('href').substr(0, 1) != '#') ) {

						// make sure this is not an absolute link with a hashtag linking to current page
						var linkTo      = jQuery(this).attr('href'),
							linkCurrent = '$permalink',
							linkDiff    = linkTo.replace(linkCurrent, '');

						// Make sure the difference doesn't start with a hashtag and not mobile size
						if ( (linkDiff.substr(0, 1) != '#') && (jQuery(window).width() > '767') ) {

							// Add Mobile helper class
							jQuery('#prettyloader-container').addClass('prettyloader-nomobile');

							// Hide Spinner
							jQuery('#prettyloader-spinner').hide();

							// Toggle PrettyLoader (open)
							prettyLoader.toggleLoader();

						} else {
							// do action without delay
							return true;
						}
					}

					// we need to wait for the animation to complete
					// otherwise Safari won't show up the smooth transition
					setTimeout(function() {

						// override default <a> action
						window.location.href = linkTo;

					}, 600);

					// disable standard methods
					return false;
				});
			";

		} else { // smooth transitions are disabled
			// do nothing
			$a_listener = '';
		}


		// Show Credit?
		if ($this->options['credits-switch'] == 1) {
			$show_credit = true;
		} else {
			$show_credit = false;
		}





		// ====================================
		// prepend the necessary HTML stuff to the body tag
		// based on the user's preferences


		// If Page Buffering is turned OFF
		if ($this->options['page-buffering'] == false) {

			$output = "
			<script type='text/javascript'>

				// Initialise PrettyLoader
				prettyLoader.initLoader('open', '$spinner_class', '$show_credit');
				prettyLoader.initEffect(".$this->options['delay'].");

				jQuery(document).ready(function() {

				});

				jQuery(window).load(function() {
					$a_listener
				});
			</script>
			";

			// in this case we need to echo the output
			echo $output;

		} else { // If Page Buffering is turned ON

			// show credit?
			if ($show_credit == true) {
				$credit_text = '<a href="http://www.webembassy.de/en/prettyloader/" target="_blank" id="prettyloader-credit">Powered by PrettyLoader</a>';
			} else {
				$credit_text = '';
			}

			$output = "

			<div id='prettyloader-container' class='open'>
				<div id='prettyloader-spinner' class='$spinner_class'></div>
				$credit_text
			</div>

			<script type='text/javascript'>
				var siteState = document.readyState;

				if (siteState == 'loading') {

					// Initialise PrettyLoader
					prettyLoader.initEffect(".$this->options['delay'].");

					jQuery(window).load(function() {
						$a_listener
					});
				}
			</script>
			";

			return $output;
		}

		return null;

	}




	// #################################################
	// ############# Buffer Manipulations ##############
	// #################################################
	public function startBuffer() {

		ob_start( array($this, 'getBuffer') );

	}

	public function getBuffer($buffer) {

		// get the code to insert
		$insert_me = $this->initJS();

		// split the HTML document
		$content = preg_split('#<body.+>#', $buffer, 2, PREG_SPLIT_OFFSET_CAPTURE);

		// get the body tag
		preg_match('#<body.+>#', $buffer, $body_tag);

		// generate output
		$output = $content[0][0] . $body_tag[0] . $insert_me . $content[1][0];

		return $output;

	}




	// #################################################
	// ############## Output PrettyLoader ##############
	// #################################################
	public function outputPrettyLoader() {

		// check page buffering settings
		if ($this->options['page-buffering'] == true) { // Page Buffering ON

			// if not backend

			if ( !is_admin() ) {
				// insert the PrettyLoader code at the beginning of <body> tag
				add_action( 'wp', array($this, 'startBuffer'), 0, 0 ); // was on init hook but we don't want this effect in WP Admin
			}

		} else { // Page Buffering OFF

			// hook the JS into footer
			add_action('wp_footer', array($this, 'initJS'), 10);

		}
	}

} 