<?php
/**
 * Created by Web Embassy.
 * Developer: Vasily Fotin
 * Date: 19/06/14
 * Time: 20:07
 */

$purecss_spinner = "
	#prettyloader-spinner,
	#prettyloader-spinner:before,
	#prettyloader-spinner:after {
		border-radius: 50%;
	}
	#prettyloader-spinner:before,
	#prettyloader-spinner:after {
		position: absolute;
		content: '';
	}
	#prettyloader-spinner:before {
		width: 5.2em;
		height: 10.2em;
		background: $spinner_bg_color;
		border-radius: 10.2em 0 0 10.2em;
		top: -0.1em;
		left: -0.1em;
		-webkit-transform-origin: 5.2em 5.1em;
		transform-origin: 5.2em 5.1em;
		-webkit-animation: prettyloader-spinner-animation 2s infinite ease 1.5s;
		animation: prettyloader-spinner-animation 2s infinite ease 1.5s;
	}
	#prettyloader-spinner {
		text-indent: -99999em;
		margin: 5em auto;
		position: relative;
		width: 10em;
		height: 10em;
		box-shadow: inset 0 0 0 1em $spinner_color;
	}
	#prettyloader-spinner:after {
		width: 5.2em;
		height: 10.2em;
		background: $spinner_bg_color;
		border-radius: 0 10.2em 10.2em 0;
		top: -0.1em;
		left: 5.1em;
		-webkit-transform-origin: 0px 5.1em;
		transform-origin: 0px 5.1em;
		-webkit-animation: prettyloader-spinner-animation 2s infinite ease;
		animation: prettyloader-spinner-animation 2s infinite ease;
	}
	@-webkit-keyframes prettyloader-spinner-animation {
		0% {
			-webkit-transform: rotate(0deg);
			transform: rotate(0deg);
		}
		100% {
			-webkit-transform: rotate(360deg);
			transform: rotate(360deg);
		}
	}
	@keyframes prettyloader-spinner-animation {
		0% {
			-webkit-transform: rotate(0deg);
			transform: rotate(0deg);
		}
		100% {
			-webkit-transform: rotate(360deg);
			transform: rotate(360deg);
		}
	}
		
		
";