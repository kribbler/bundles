<?php
/**
 * Created by Web Embassy.
 * Developer: Vasily Fotin
 * Date: 19/06/14
 * Time: 20:07
 */

$purecss_spinner = "
	#prettyloader-spinner {
		text-indent: -9999em;
		overflow: hidden;
		width: 1em;
		height: 1em;
		border-radius: 50%;
		-webkit-animation: prettyloader-spinner-animation 1.7s infinite ease;
		animation: prettyloader-spinner-animation 1.7s infinite ease;
	}

	@-webkit-keyframes prettyloader-spinner-animation {
			0% {
				-webkit-transform: rotate(0deg);
				transform: rotate(0deg);
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.11em -0.83em 0 -0.42em $spinner_color, -0.11em -0.83em 0 -0.44em $spinner_color, -0.11em -0.83em 0 -0.46em $spinner_color, -0.11em -0.83em 0 -0.477em $spinner_color;
			}
			5%,
			95% {
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.11em -0.83em 0 -0.42em $spinner_color, -0.11em -0.83em 0 -0.44em $spinner_color, -0.11em -0.83em 0 -0.46em $spinner_color, -0.11em -0.83em 0 -0.477em $spinner_color;
			}
			30% {
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.51em -0.66em 0 -0.42em $spinner_color, -0.75em -0.36em 0 -0.44em $spinner_color, -0.83em -0.03em 0 -0.46em $spinner_color, -0.81em 0.21em 0 -0.477em $spinner_color;
			}
			55% {
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.29em -0.78em 0 -0.42em $spinner_color, -0.43em -0.72em 0 -0.44em $spinner_color, -0.52em -0.65em 0 -0.46em $spinner_color, -0.57em -0.61em 0 -0.477em $spinner_color;
			}
			100% {
				-webkit-transform: rotate(360deg);
				transform: rotate(360deg);
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.11em -0.83em 0 -0.42em $spinner_color, -0.11em -0.83em 0 -0.44em $spinner_color, -0.11em -0.83em 0 -0.46em $spinner_color, -0.11em -0.83em 0 -0.477em $spinner_color;
			}
		}
		@keyframes prettyloader-spinner-animation {
			0% {
				-webkit-transform: rotate(0deg);
				transform: rotate(0deg);
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.11em -0.83em 0 -0.42em $spinner_color, -0.11em -0.83em 0 -0.44em $spinner_color, -0.11em -0.83em 0 -0.46em $spinner_color, -0.11em -0.83em 0 -0.477em $spinner_color;
			}
			5%,
			95% {
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.11em -0.83em 0 -0.42em $spinner_color, -0.11em -0.83em 0 -0.44em $spinner_color, -0.11em -0.83em 0 -0.46em $spinner_color, -0.11em -0.83em 0 -0.477em $spinner_color;
			}
			30% {
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.51em -0.66em 0 -0.42em $spinner_color, -0.75em -0.36em 0 -0.44em $spinner_color, -0.83em -0.03em 0 -0.46em $spinner_color, -0.81em 0.21em 0 -0.477em $spinner_color;
			}
			55% {
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.29em -0.78em 0 -0.42em $spinner_color, -0.43em -0.72em 0 -0.44em $spinner_color, -0.52em -0.65em 0 -0.46em $spinner_color, -0.57em -0.61em 0 -0.477em $spinner_color;
			}
			100% {
				-webkit-transform: rotate(360deg);
				transform: rotate(360deg);
				box-shadow: -0.11em -0.83em 0 -0.4em $spinner_color, -0.11em -0.83em 0 -0.42em $spinner_color, -0.11em -0.83em 0 -0.44em $spinner_color, -0.11em -0.83em 0 -0.46em $spinner_color, -0.11em -0.83em 0 -0.477em $spinner_color;
			}
		}
";