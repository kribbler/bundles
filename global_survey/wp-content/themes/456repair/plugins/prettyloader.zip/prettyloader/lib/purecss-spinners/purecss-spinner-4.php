<?php
/**
 * Created by Web Embassy.
 * Developer: Vasily Fotin
 * Date: 19/06/14
 * Time: 20:07
 */

$purecss_spinner = "
	#prettyloader-spinner,
	#prettyloader-spinner:before,
	#prettyloader-spinner:after {
		background: $spinner_color;
		-webkit-animation: prettyloader-spinner-animation 1s infinite ease-in-out;
		animation: prettyloader-spinner-animation 1s infinite ease-in-out;
		width: 1em;
		height: 4em;
	}
	#prettyloader-spinner:before,
	#prettyloader-spinner:after {
		position: absolute;
		top: 0;
		content: '';
	}
	#prettyloader-spinner:before {
		left: -1.5em;
	}
	#prettyloader-spinner {
		text-indent: -9999em;
		-webkit-animation-delay: -0.16s;
		animation-delay: -0.16s;
	}
	#prettyloader-spinner:after {
		left: 1.5em;
		-webkit-animation-delay: -0.32s;
		animation-delay: -0.32s;
	}
	
	@-webkit-keyframes prettyloader-spinner-animation {
			0%,
			80%,
			100% {
				box-shadow: 0 0 $spinner_color;
				height: 4em;
			}
			40% {
				box-shadow: 0 -2em $spinner_color;
				height: 5em;
			}
		}
		@keyframes prettyloader-spinner-animation {
			0%,
			80%,
			100% {
				box-shadow: 0 0 $spinner_color;
				height: 4em;
			}
			40% {
				box-shadow: 0 -2em $spinner_color;
				height: 5em;
			}
		}
";