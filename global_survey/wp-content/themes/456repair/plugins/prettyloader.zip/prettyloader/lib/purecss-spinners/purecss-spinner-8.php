<?php
/**
 * Created by Web Embassy.
 * Developer: Vasily Fotin
 * Date: 19/06/14
 * Time: 20:07
 */

$purecss_spinner = "
	#prettyloader-spinner {
		margin: 5em auto;
		width: 1em;
		height: 1em;
		border-radius: 50%;
		position: relative;
		text-indent: -9999em;
		-webkit-animation: prettyloader-spinner-animation 1.3s infinite linear;
		animation: prettyloader-spinner-animation 1.3s infinite linear;
	}
	@-webkit-keyframes prettyloader-spinner-animation {
		0%,
		100% {
			box-shadow: 0em -3em 0em 0.2em $spinner_color, 2em -2em 0 0em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 -0.5em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 0em $spinner_color;
		}
		12.5% {
			box-shadow: 0em -3em 0em 0em $spinner_color, 2em -2em 0 0.2em $spinner_color, 3em 0em 0 0em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 -0.5em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		25% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 0em $spinner_color, 3em 0em 0 0.2em $spinner_color, 2em 2em 0 0em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 -0.5em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		37.5% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 0em $spinner_color, 2em 2em 0 0.2em $spinner_color, 0em 3em 0 0em $spinner_color, -2em 2em 0 -0.5em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		50% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 0em $spinner_color, 0em 3em 0 0.2em $spinner_color, -2em 2em 0 0em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		62.5% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 0em $spinner_color, -2em 2em 0 0.2em $spinner_color, -3em 0em 0 0em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		75% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 0em $spinner_color, -3em 0em 0 0.2em $spinner_color, -2em -2em 0 0em $spinner_color;
		}
		87.5% {
			box-shadow: 0em -3em 0em 0em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 0em $spinner_color, -3em 0em 0 0em $spinner_color, -2em -2em 0 0.2em $spinner_color;
		}
	}
	@keyframes prettyloader-spinner-animation {
		0%,
		100% {
			box-shadow: 0em -3em 0em 0.2em $spinner_color, 2em -2em 0 0em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 -0.5em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 0em $spinner_color;
		}
		12.5% {
			box-shadow: 0em -3em 0em 0em $spinner_color, 2em -2em 0 0.2em $spinner_color, 3em 0em 0 0em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 -0.5em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		25% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 0em $spinner_color, 3em 0em 0 0.2em $spinner_color, 2em 2em 0 0em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 -0.5em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		37.5% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 0em $spinner_color, 2em 2em 0 0.2em $spinner_color, 0em 3em 0 0em $spinner_color, -2em 2em 0 -0.5em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		50% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 0em $spinner_color, 0em 3em 0 0.2em $spinner_color, -2em 2em 0 0em $spinner_color, -3em 0em 0 -0.5em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		62.5% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 0em $spinner_color, -2em 2em 0 0.2em $spinner_color, -3em 0em 0 0em $spinner_color, -2em -2em 0 -0.5em $spinner_color;
		}
		75% {
			box-shadow: 0em -3em 0em -0.5em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 0em $spinner_color, -3em 0em 0 0.2em $spinner_color, -2em -2em 0 0em $spinner_color;
		}
		87.5% {
			box-shadow: 0em -3em 0em 0em $spinner_color, 2em -2em 0 -0.5em $spinner_color, 3em 0em 0 -0.5em $spinner_color, 2em 2em 0 -0.5em $spinner_color, 0em 3em 0 -0.5em $spinner_color, -2em 2em 0 0em $spinner_color, -3em 0em 0 0em $spinner_color, -2em -2em 0 0.2em $spinner_color;
		}
	}
";