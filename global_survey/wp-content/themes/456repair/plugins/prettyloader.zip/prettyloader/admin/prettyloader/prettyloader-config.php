<?php

/**
  ReduxFramework Sample Config File
  For full documentation, please visit: https://docs.reduxframework.com
 * */

if (!class_exists('Redux_Framework_sample_config')) {

    class Redux_Framework_sample_config {

        public $args        = array();
        public $sections    = array();
        public $theme;
        public $ReduxFramework;

        public function __construct() {

            if (!class_exists('ReduxFramework')) {
                return;
            }

            // This is needed. Bah WordPress bugs.  ;)
            if (  true == Redux_Helpers::isTheme(__FILE__) ) {
                $this->initSettings();
            } else {
                add_action('plugins_loaded', array($this, 'initSettings'), 10);
            }

        }

        public function initSettings() {

            // Set the default arguments
            $this->setArguments();

            // Set a few help tabs so you can see how it's done
            $this->setHelpTabs();

            // Create the sections and fields
            $this->setSections();

            if (!isset($this->args['opt_name'])) { // No errors please
                return;
            }

            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }

        public function setSections() {

	        // get the URL of this file's location
	        $prettyLoaderSettingsLocation = plugin_dir_url( __FILE__ );

            // ACTUAL DECLARATION OF SECTIONS
            $this->sections[] = array(
                'title'     => __('Main Settings', 'prettyloader-options'),
                'desc'      => __('', 'prettyloader-options'),
                'icon'      => 'el-icon-cogs',
                'fields'    => array(
	                array(
		                'id'        => 'prettyloader-switch',
		                'type'      => 'switch',
		                'title'     => __('PrettyLoader Page Preloader', 'prettyloader-options'),
		                'subtitle'  => __('Enable / disable PrettyLoader.', 'prettyloader-options'),
		                'default'   => true,
	                ),
	                array(
		                'id'            => 'delay',
		                'type'          => 'slider',
		                'title'         => __('Page Preloader Delays', 'prettyloader-options'),
		                'subtitle'      => __('Delay before the preloader fades away, after the site content has been loaded.', 'prettyloader-options'),
		                'desc'          => __('Milliseconds', 'prettyloader-options'),
		                'default'       => 1000,
		                'min'           => 0,
		                'step'          => 100,
		                'max'           => 3000,
		                'display_value' => 'text'
	                ),
	                array(
		                'id'        => 'page-transition',
		                'type'      => 'radio',
		                'title'     => __('Page Transition', 'prettyloader-options'),
		                'subtitle'  => __('Choose the page transition effect based on your preference.', 'prettyloader-options'),
		                'desc'      => __('', 'prettyloader-options'),
		                'options'   => array(
			                '1' => 'Simple Fade',
			                '2' => 'Corner',
			                '3' => 'Slide Down',
			                '4' => 'Scale In',
			                '5' => 'Genie'
		                ),
		                'default'   => '1'
	                ),
	                array(
		                'id'        => 'smooth-page-transitions',
		                'type'      => 'switch',
		                'title'     => __('Smooth Page Transitions', 'prettyloader-options'),
		                'subtitle'  => __('Enable page transition before the new page is loaded. It\'s automatically turned off on mobile devices to prevent unpredictable browser behaviour. <strong>IMPORTANT! Disable this feature if you are expiriencing compatibility issues.</strong>', 'prettyloader-options'),
		                'default'   => 0,
		                'on'        => 'Enable',
		                'off'       => 'Disable',
	                ),
	                array(
		                'id'        => 'credits-switch',
		                'type'      => 'switch',
		                'title'     => __('Developer Credits', 'prettyloader-options'),
		                'subtitle'  => __('Show a small link at the bottom of the preloader. This is by no means necessary, however we would <strong>greatly appreciate</strong> if you do so.', 'prettyloader-options'),
		                'default'   => false,
		                'on'        => 'Show',
		                'off'       => 'Hide',
	                ),
	                array(
		                'id'        => 'page-buffering',
		                'type'      => 'switch',
		                'title'     => __('Page Buffering', 'prettyloader-options'),
		                'subtitle'  => __('PrettyLoader is dynamically adding HTML to the body tag. If you disable page buffering, small graphical lags may occur in Safari. <strong>Don\'t turn it off if you are unsure.</strong>', 'prettyloader-options'),
		                'default'   => true,
	                ),
	                array(
		                'id'        => 'force-jquery',
		                'type'      => 'switch',
		                'title'     => __('Force jQuery CDN', 'prettyloader-options'),
		                'subtitle'  => __('In case your jQuery version is very outdated or not used at all (for some reason), turn this feature on. If you don\'t know what it means, leave it off.', 'prettyloader-options'),
		                'default'   => false,
	                ),
	                array(
		                'id'        => 'hide-mobile',
		                'type'      => 'switch',
		                'title'     => __('Hide on Mobile Devices', 'prettyloader-options'),
		                'subtitle'  => __('Completely hide PrettyLoader on mobile phones & tablets.', 'prettyloader-options'),
		                'default'   => false,
	                ),
                )
            );

	        // ----------------------------------

	        $this->sections[] = array(
		        'title'     => __('Appearance', 'prettyloader-options'),
		        'desc'      => __('', 'prettyloader-options'),
		        'icon'      => 'el-icon-brush',
		        'fields'    => array(
			        array(
				        'id'        => 'spinner-size',
				        'type'      => 'button_set',
				        'title'     => __('Spinner Size', 'prettyloader-options'),
				        'subtitle'  => __('Choose the size of the preloader spinner. It will be adopted automatically for all display sizes. <strong>Beware.</strong> The bigger the spinner size (if spinner type set to image) the more traffic.', 'prettyloader-options'),
				        'desc'      => __('', 'prettyloader-options'),

				        'options'   => array(
					        '1' => 'Small',
					        '2' => 'Medium',
					        '3' => 'Large'
				        ),
				        'default'   => '3'
			        ),
			        array(
				        'id'        => 'type-switch',
				        'type'      => 'switch',
				        'title'     => __('Spinner Type', 'prettyloader-options'),
				        'subtitle'  => __('PrettyLoader features two types of page preloaders - images & pure CSS. CSS works faster, but it depends on your personal preference.', 'prettyloader-options'),
				        'default'   => true,
				        'on'        => 'Images',
				        'off'       => 'Pure CSS',
			        ),
			        // -------------
			        // IMAGE SPINNER
			        array(
				        'id'        => 'spinner-image-graphics',
				        'type'      => 'image_select',
				        'required'  => array('type-switch', '=', '1'),
				        'compiler'  => true,
				        'title'     => __('Spinner Graphics', 'prettyloader-options'),
				        'subtitle'  => __('Choose the spinner icon you would like to use for the page preloader.', 'prettyloader-options'),
				        'options'   => array(
					        '1' => array('alt' => 'spinner01', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-01.gif'),
					        '2' => array('alt' => 'spinner02', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-02.gif'),
					        '3' => array('alt' => 'spinner03', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-03.gif'),
					        '4' => array('alt' => 'spinner04', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-04.gif'),
					        '5' => array('alt' => 'spinner05', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-05.gif'),
					        '6' => array('alt' => 'spinner06', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-06.gif'),
					        '7' => array('alt' => 'spinner07', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-07.gif'),
					        '8' => array('alt' => 'spinner08', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-08.gif'),
					        '9' => array('alt' => 'spinner09', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-09.gif'),
					        '10' => array('alt' => 'spinner10', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-10.gif'),
					        '11' => array('alt' => 'spinner11', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-11.gif'),
					        '12' => array('alt' => 'spinner12', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-12.gif'),
					        '13' => array('alt' => 'spinner13', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-13.gif'),
					        '14' => array('alt' => 'spinner14', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-14.gif'),
					        '15' => array('alt' => 'spinner15', 'img' => $prettyLoaderSettingsLocation.'img/image-spinner-15.gif'),
				        ),
				        'default'   => '13'
			        ),
			        // ----------------
			        // PURE CSS SPINNER
			        array(
				        'id'        => 'spinner-purecss-graphics',
				        'type'      => 'image_select',
				        'required'  => array('type-switch', '=', '0'),
				        'compiler'  => true,
				        'title'     => __('Spinner Graphics', 'prettyloader-options'),
				        'subtitle'  => __('Choose the spinner icon you would like to use for the page preloader. <strong>Caution.</strong> Spinners #5 and #6 do not work with tricolor & image backgrounds.', 'prettyloader-options'),
				        'options'   => array(
					        '1' => array('alt' => 'spinner01', 'img' => $prettyLoaderSettingsLocation.'img/spinner-01.png'),
					        '2' => array('alt' => 'spinner02', 'img' => $prettyLoaderSettingsLocation.'img/spinner-02.png'),
					        '3' => array('alt' => 'spinner03', 'img' => $prettyLoaderSettingsLocation.'img/spinner-03.png'),
					        '4' => array('alt' => 'spinner04', 'img' => $prettyLoaderSettingsLocation.'img/spinner-04.png'),
					        '5' => array('alt' => 'spinner05', 'img' => $prettyLoaderSettingsLocation.'img/spinner-05.png'),
					        '6' => array('alt' => 'spinner06', 'img' => $prettyLoaderSettingsLocation.'img/spinner-06.png'),
					        '7' => array('alt' => 'spinner07', 'img' => $prettyLoaderSettingsLocation.'img/spinner-07.png'),
					        '8' => array('alt' => 'spinner08', 'img' => $prettyLoaderSettingsLocation.'img/spinner-08.png'),
				        ),
				        'default'   => '2'
			        ),
			        array(
				        'id'        => 'spinner-purecss-color',
				        'type'      => 'color',
				        'required'  => array('type-switch', '=', '0'),
				        'title'     => __('Spinner color', 'prettyloader-options'),
				        'subtitle'  => __('Choose the foreground color for the CSS-based spinner.', 'prettyloader-options'),
				        'default'   => '#16a085',
				        'validate'  => 'color',
			        ),
			        // ----------------
			        array(
				        'id'        => 'background-style',
				        'type'      => 'button_set',
				        'title'     => __('Background Style', 'prettyloader-options'),
				        'subtitle'  => __('Choose the style of background you prefer to use. Color is just a basic single-colored background. Tricolor is a combination of three colors / gradients. And third option is an image (tiled or full-sized).', 'prettyloader-options'),
				        'desc'      => __('', 'prettyloader-options'),

				        'options'   => array(
					        '1' => 'Color',
					        '2' => 'Tricolor',
					        '3' => 'Image'
				        ),
				        'default'   => '1'
			        ),
			        // ----------------
			        // Background Color
			        array(
				        'id'        => 'background-color',
				        'type'      => 'color',
				        'required'  => array('background-style', '=', '1'),
				        //'output'    => array('.site-title'),
				        'title'     => __('Background Color', 'prettyloader-options'),
				        'subtitle'  => __('', 'prettyloader-options'),
				        'default'   => '#FFFFFF',
				        'validate'  => 'color',
			        ),
			        // -------------------
			        // Tricolor Background
			        array(
				        'id'        => 'tricolor-background-top',
				        'type'      => 'color',
				        'required'  => array('background-style', '=', '2'),
				        'title'     => __('Background Color - Top', 'prettyloader-options'),
				        'subtitle'  => __('Set the color for the top gradient.', 'prettyloader-options'),
				        'default'   => '#7fb4df',
				        'validate'  => 'color',
			        ),
			        array(
				        'id'        => 'tricolor-background-left',
				        'type'      => 'color',
				        'required'  => array('background-style', '=', '2'),
				        'title'     => __('Background Color - Left', 'prettyloader-options'),
				        'subtitle'  => __('Set the color for the left gradient.', 'prettyloader-options'),
				        'default'   => '#16a085',
				        'validate'  => 'color',
			        ),
			        array(
				        'id'        => 'tricolor-background-right',
				        'type'      => 'color',
				        'required'  => array('background-style', '=', '2'),
				        'title'     => __('Background Color - Right', 'prettyloader-options'),
				        'subtitle'  => __('Set the color for the right gradient.', 'prettyloader-options'),
				        'default'   => '#f9f20e',
				        'validate'  => 'color',
			        ),
			        // ----------------
			        // Background Image
			        array(
				        'id'        => 'background-image',
				        'type'      => 'media',
				        'required'  => array('background-style', '=', '3'),
				        'title'     => __('Background Image', 'prettyloader-options'),
				        'desc'      => __('Upload an image you would like to use as the preloader background.', 'prettyloader-options'),
				        'subtitle'  => __('', 'prettyloader-options'),
			        ),
			        array(
				        'id'        => 'background-image-repeat',
				        'type'      => 'switch',
				        'required'  => array('background-style', '=', '3'),
				        'title'     => __('Repeat Background Image', 'prettyloader-options'),
				        'subtitle'  => __('Turn this option on if you\'re using tiling image. Leave this option off if you\'re using full-sized image.', 'prettyloader-options'),
				        'default'   => false,
				        'on'        => 'Yes',
				        'off'       => 'No',
			        ),
			        // -----------------
			        // Background Border
			        array(
				        'id'        => 'background-border-switch',
				        'type'      => 'switch',
				        'title'     => __('Background Border', 'prettyloader-options'),
				        'subtitle'  => __('Enable or disable the container border.', 'prettyloader-options'),
				        'default'   => true,
				        'on'        => 'Enable',
				        'off'       => 'Disable',
			        ),
			        array(
				        'id'            => 'background-border-width',
				        'type'          => 'slider',
				        'required'      => array('background-border-switch', '=', '1'),
				        'title'         => __('Background Border Width', 'prettyloader-options'),
				        'subtitle'      => __('Determine the size of the background border.', 'prettyloader-options'),
				        'desc'          => __('Pixels', 'prettyloader-options'),
				        'default'       => 30,
				        'min'           => 1,
				        'step'          => 1,
				        'max'           => 100,
				        'display_value' => 'text'
			        ),
			        array(
				        'id'        => 'background-border-color',
				        'type'      => 'color',
				        'required'  => array('background-border-switch', '=', '1'),
				        'title'     => __('Background Border Color', 'prettyloader-options'),
				        'subtitle'  => __('Set the container border color.', 'prettyloader-options'),
				        'default'   => '#69c2d3',
				        'validate'  => 'color',
			        ),
			        array(
				        'id'            => 'background-border-opacity',
				        'type'          => 'slider',
				        'required'      => array('background-border-switch', '=', '1'),
				        'title'         => __('Background Border Opacity', 'prettyloader-options'),
				        'subtitle'      => __('Make the background border translucent or set this field to 100%.', 'prettyloader-options'),
				        'desc'          => __('%', 'prettyloader-options'),
				        'default'       => 50,
				        'min'           => 0,
				        'step'          => 5,
				        'max'           => 100,
				        'display_value' => 'text'
			        ),
		        )
	        );

	        // ----------------------------------

	        $this->sections[] = array(
		        'title'     => __('Custom Styles', 'prettyloader-options'),
		        'desc'      => __('', 'prettyloader-options'),
		        'icon'      => 'el-icon-css',
		        'fields'    => array(
			        array(
				        'id'        => 'custom-css',
				        'type'      => 'ace_editor',
				        'title'     => __('CSS Code', 'prettyloader-options'),
				        'subtitle'  => __('Enter your CSS code in this editor. Make sure your code is valid.', 'prettyloader-options'),
				        'mode'      => 'css',
				        'theme'     => 'monokai',
				        'desc'      => '',
				        'default'   => ""
			        ),
		        )
	        );

	        $this->sections[] = array(
		        'type' => 'divide',
	        );
        }

        public function setHelpTabs() {

        }

        /**

          All the possible arguments for Redux.
          For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments

         * */
        public function setArguments() {

            $this->args = array(
                'opt_name'          => 'prettyloader_options',
                'display_name'      => 'PrettyLoader Settings',
                'display_version'   => '1.0',
                'menu_type'         => 'submenu',                  // Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                'allow_sub_menu'    => false,                   // Show the sections below the admin menu item or not
                'menu_title'        => __('PrettyLoader', 'prettyloader-options'),
                'page_title'        => __('PrettyLoader', 'prettyloader-options'),

                // You will need to generate a Google API key to use this feature.
                // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                'google_api_key' => '', // Must be defined to add google fonts to the typography module

                'async_typography'  => false,                   // Use a asynchronous font on the front end or font string
                'admin_bar'         => false,                   // Show the panel pages on the admin bar
                'global_variable'   => '',                      // Set a different name for your global variable other than the opt_name
                'dev_mode'          => false,                   // Show the time the page took to load, etc
                'customizer'        => true,                    // Enable basic customizer support

                // OPTIONAL -> Give you extra features
                'page_priority'     => null,                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                'page_parent'       => 'themes.php',            // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                'page_permissions'  => 'manage_options',        // Permissions needed to access the options panel.
                'menu_icon'         => '',                      // Specify a custom URL to an icon
                'last_tab'          => '',                      // Force your panel to always open to a specific tab (by id)
                'page_icon'         => 'icon-themes',           // Icon displayed in the admin panel next to your menu_title
                'page_slug'         => '_options',              // Page slug used to denote the panel
                'save_defaults'     => true,                    // On load save the defaults to DB before user clicks save or not
                'default_show'      => false,                   // If true, shows the default value next to each field that is not the default value.
                'default_mark'      => '',                      // What to print by the field's title if the value shown is default. Suggested: *
                'show_import_export' => true,                   // Shows the Import/Export panel when not used as a field.

                // CAREFUL -> These options are for advanced use only
                'transient_time'    => 60 * MINUTE_IN_SECONDS,
                'output'            => true,                    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                'output_tag'        => true,                    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                'footer_credit'     => '&copy; 2014 <a href="http://www.webembassy.de/en/">Web Embassy</a>',

                // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                'database'              => '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                'system_info'           => false, // REMOVE

                // HINTS
                'hints' => array(
                    'icon'          => 'icon-question-sign',
                    'icon_position' => 'right',
                    'icon_color'    => 'lightgray',
                    'icon_size'     => 'normal',
                    'tip_style'     => array(
                        'color'         => 'light',
                        'shadow'        => true,
                        'rounded'       => false,
                        'style'         => '',
                    ),
                    'tip_position'  => array(
                        'my' => 'top left',
                        'at' => 'bottom right',
                    ),
                    'tip_effect'    => array(
                        'show'          => array(
                            'effect'        => 'slide',
                            'duration'      => '500',
                            'event'         => 'mouseover',
                        ),
                        'hide'      => array(
                            'effect'    => 'slide',
                            'duration'  => '500',
                            'event'     => 'click mouseleave',
                        ),
                    ),
                )
            );


            // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
            $this->args['share_icons'][] = array(
                'url'   => 'http://twitter.com/webembassy',
                'title' => 'Follow us on Twitter',
                'icon'  => 'el-icon-twitter'
            );

            // Panel Intro text -> before the form
            if (!isset($this->args['global_variable']) || $this->args['global_variable'] !== false) {
                if (!empty($this->args['global_variable'])) {
                    $v = $this->args['global_variable'];
                } else {
                    $v = str_replace('-', '_', $this->args['opt_name']);
                }
                $this->args['intro_text'] = __('<p>Welcome to <a href="http://www.webembassy.de/en/prettyloader/" target="_blank">PrettyLoader</a> - the sweet & pretty page loader for your WordPress-powered website. If you\'re expiriencing any difficulties please refer to the documentation or support forum.</p>', 'prettyloader-options');
            } else {
                $this->args['intro_text'] = __('', 'prettyloader-options');
            }

            // Add content after the form.
            $this->args['footer_text'] = __('', 'prettyloader-options');
        }

    }

    global $reduxConfig;
    $reduxConfig = new Redux_Framework_sample_config();
}