<?php
/**
 * The Sidebar containing the left widget areas.
 *
 * @package liva
 * @since liva 1.0
 */
?>
<div class="left_sidebar">
	<?php dynamic_sidebar( ts_get_single_post_sidebar_id('left_sidebar') ); ?>
</div>