<?php
/**
 * Widgets
 *
 * @package framework
 * @since framework 1.0
 */

require_once get_template_directory().'/inc/widgets/WP_Flickr_Tiles_Widget.class.php';
require_once get_template_directory().'/inc/widgets/WP_Latest_Posts_Widget.class.php';
require_once get_template_directory().'/inc/widgets/WP_Latest_Tweets_Widget.class.php';
require_once get_template_directory().'/inc/widgets/WP_Multi_Posts_Widget.class.php';
require_once get_template_directory().'/inc/widgets/WP_Portfolio_Widget.class.php';
require_once get_template_directory().'/inc/widgets/WP_Side_Navi_Widget.class.php';
require_once get_template_directory().'/inc/widgets/WP_Social_Icons_Widget.class.php';
require_once get_template_directory().'/inc/widgets/WP_Testimonial_Widget.class.php';
