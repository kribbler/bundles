<?php
/**
 * The Sidebar containing the right widget areas.
 *
 * @package liva
 * @since liva 1.0
 */
?>
<div class="right_sidebar">
	<?php dynamic_sidebar( ts_get_single_post_sidebar_id('right_sidebar') ); ?>
</div>